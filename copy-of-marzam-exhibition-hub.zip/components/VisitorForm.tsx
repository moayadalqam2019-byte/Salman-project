import React, { useState, useEffect } from 'react';
import { VisitorInterest } from '../types';
import { saveRequest } from '../services/storage';
import { Send, CheckCircle, MapPin, Armchair, AlertCircle, Building2 } from 'lucide-react';

interface VisitorFormProps {
  initialMessage?: string;
  onReset?: () => void;
}

export const VisitorForm: React.FC<VisitorFormProps> = ({ initialMessage, onReset }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    organization: '',
    email: '',
    phone: '',
    interest: VisitorInterest.GENERAL_INQUIRY,
    message: ''
  });
  const [errors, setErrors] = useState<{email?: string; phone?: string}>({});
  const [submitted, setSubmitted] = useState(false);

  // Update message if initialMessage prop changes (e.g. from scanner)
  useEffect(() => {
    if (initialMessage) {
      setFormData(prev => ({
        ...prev,
        message: `Inquiry regarding: ${initialMessage}`
      }));
    }
  }, [initialMessage]);

  const validateForm = (): boolean => {
    const newErrors: {email?: string; phone?: string} = {};
    
    // Email Validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    // Phone Validation
    const phoneCleaned = formData.phone.replace(/\D/g, '');
    const phoneCharsValid = /^[\d\s+\-()]+$/.test(formData.phone);
    
    if (!formData.phone.trim()) {
      newErrors.phone = "Phone number is required.";
    } else if (phoneCleaned.length < 7 || !phoneCharsValid) {
      newErrors.phone = "Please enter a valid phone number (at least 7 digits).";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      saveRequest(formData);
      setSubmitted(true);
    }
  };

  const handleReset = () => {
    setSubmitted(false);
    setFormData({ 
      fullName: '', 
      organization: '', 
      email: '', 
      phone: '', 
      interest: VisitorInterest.GENERAL_INQUIRY, 
      message: '' 
    });
    setErrors({});
    if (onReset) onReset();
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center bg-white rounded-xl shadow-2xl max-w-md mx-auto mt-10 border border-green-100 overflow-hidden">
        <style>{`
          @keyframes scale-up-elastic {
            0% { transform: scale(0); opacity: 0; }
            60% { transform: scale(1.1); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
          }
          @keyframes slide-up-fade {
            0% { transform: translateY(20px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
          }
        `}</style>
        
        <div 
          className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-6 shadow-sm text-green-600"
          style={{ animation: 'scale-up-elastic 0.7s cubic-bezier(0.34, 1.56, 0.64, 1) forwards' }}
        >
          <CheckCircle className="w-10 h-10" strokeWidth={3} />
        </div>
        
        <div style={{ animation: 'slide-up-fade 0.5s ease-out 0.2s both' }}>
            <h2 className="text-3xl font-serif font-bold text-stone-800 mb-3">Request Sent</h2>
            <p className="text-stone-600 mb-8 text-lg leading-relaxed">
              Thank you for connecting with us.<br/>We will review your request shortly.
            </p>
            <button 
              onClick={handleReset}
              className="px-6 py-2.5 bg-stone-900 hover:bg-stone-800 text-white font-medium rounded-lg transition-all duration-200 transform hover:-translate-y-0.5 shadow-md"
            >
              Submit another request
            </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-stone-200 mt-6">
      <div className="bg-stone-900 p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10 transform translate-x-1/4 -translate-y-1/4">
          <svg width="200" height="200" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M100 0L200 100L100 200L0 100L100 0Z" fill="white"/>
          </svg>
        </div>
        <div className="flex items-center gap-3 mb-2">
           <Armchair className="text-amber-500" size={32}/>
           <h2 className="text-3xl font-serif font-bold">Visitor Registration</h2>
        </div>
        <div className="flex items-center space-x-2 text-amber-400 text-sm font-medium">
          <MapPin size={16} />
          <span>Marzam Exhibition • Dec 9-14</span>
        </div>
        <p className="mt-4 text-stone-300 text-sm leading-relaxed">
          Connect with us for design consultations, product inquiries, or collaborations. Please fill out your details below.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold text-stone-700 mb-2">Full Name</label>
            <input
              type="text"
              required
              className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-all"
              placeholder="Jane Doe"
              value={formData.fullName}
              onChange={(e) => setFormData({...formData, fullName: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-stone-700 mb-2">Company (Optional)</label>
            <div className="relative">
              <input
                type="text"
                className="w-full px-4 py-3 pl-10 rounded-lg border border-stone-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-all"
                placeholder="Design Studio Co."
                value={formData.organization}
                onChange={(e) => setFormData({...formData, organization: e.target.value})}
              />
              <Building2 className="absolute left-3 top-3.5 text-stone-400" size={18} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-bold text-stone-700 mb-2">Email</label>
            <input
              type="email"
              className={`w-full px-4 py-3 rounded-lg border ${errors.email ? 'border-red-500 focus:border-red-500 focus:ring-red-200' : 'border-stone-300 focus:ring-amber-500 focus:border-amber-500'} focus:ring-2 outline-none transition-all`}
              placeholder="jane@example.com"
              value={formData.email}
              onChange={(e) => {
                setFormData({...formData, email: e.target.value});
                if (errors.email) setErrors({...errors, email: undefined});
              }}
            />
            {errors.email && (
              <p className="text-red-500 text-xs mt-2 flex items-center gap-1 animate-fade-in">
                <AlertCircle size={12} /> {errors.email}
              </p>
            )}
          </div>
          <div>
            <label className="block text-sm font-bold text-stone-700 mb-2">Phone</label>
            <input
              type="tel"
              className={`w-full px-4 py-3 rounded-lg border ${errors.phone ? 'border-red-500 focus:border-red-500 focus:ring-red-200' : 'border-stone-300 focus:ring-amber-500 focus:border-amber-500'} focus:ring-2 outline-none transition-all`}
              placeholder="+1 (555) 000-0000"
              value={formData.phone}
              onChange={(e) => {
                setFormData({...formData, phone: e.target.value});
                if (errors.phone) setErrors({...errors, phone: undefined});
              }}
            />
            {errors.phone && (
              <p className="text-red-500 text-xs mt-2 flex items-center gap-1 animate-fade-in">
                <AlertCircle size={12} /> {errors.phone}
              </p>
            )}
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-stone-700 mb-2">Primary Interest</label>
          <div className="relative">
            <select
              className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-all appearance-none bg-white"
              value={formData.interest}
              onChange={(e) => setFormData({...formData, interest: e.target.value as VisitorInterest})}
            >
              {Object.values(VisitorInterest).map(interest => (
                <option key={interest} value={interest}>{interest}</option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-stone-500">
              <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-stone-700 mb-2">Message / Request</label>
          <textarea
            required
            rows={4}
            className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition-all resize-none"
            placeholder="I'm interested in the modular sofa collection..."
            value={formData.message}
            onChange={(e) => setFormData({...formData, message: e.target.value})}
          />
        </div>

        <button
          type="submit"
          className="w-full bg-stone-900 hover:bg-stone-800 text-white font-bold py-4 rounded-lg shadow-lg transform transition hover:-translate-y-0.5 flex items-center justify-center space-x-2"
        >
          <span>Submit Request</span>
          <Send size={18} />
        </button>
      </form>
    </div>
  );
};