import { GoogleGenAI, Type } from "@google/genai";
import { VisitorRequest, AnalysisResult } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const analyzeVisitorData = async (requests: VisitorRequest[]): Promise<AnalysisResult> => {
  if (requests.length === 0) {
    return {
      summary: "No data to analyze yet.",
      topInterests: [],
      suggestedAction: "Wait for visitors to submit forms."
    };
  }

  // Sanitize data for the prompt, including organization info if available
  const dataSummary = requests.map(r => 
    `Visitor: ${r.fullName} (${r.organization || 'Individual'}), Interest: ${r.interest}, Message: ${r.message}`
  ).join('\n');

  const model = "gemini-2.5-flash";
  const prompt = `
    Analyze the following visitor requests from the Marzam Interior Design Exhibition.
    
    1. Provide a brief summary of the overall sentiment and intent.
    2. Analyze the mix between Commercial/B2B (Companies) vs Residential (Individuals).
    3. Identify the top 3 specific interests or design themes mentioned.
    4. Suggest a specific business action for the exhibition owner based on this data.
    
    Data:
    ${dataSummary}
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            topInterests: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            suggestedAction: { type: Type.STRING }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as AnalysisResult;

  } catch (error) {
    console.error("Gemini Analysis Failed", error);
    return {
      summary: "Failed to analyze data.",
      topInterests: [],
      suggestedAction: "Check API key or connection."
    };
  }
};

export const generateEmailDraft = async (visitor: VisitorRequest): Promise<string> => {
  const model = "gemini-2.5-flash";
  const prompt = `
    Write a polite, professional, and personalized follow-up email for a visitor to the Marzam Interior Design Exhibition.
    
    Visitor Name: ${visitor.fullName}
    Organization: ${visitor.organization || 'N/A'}
    Interest: ${visitor.interest}
    Their Message: "${visitor.message}"
    
    The email should thank them for visiting between Dec 9-14.
    If they are from an organization, tailor the tone to be more B2B focused.
    Acknowledge their specific interest and propose a consultation or catalog review.
    Keep it under 150 words.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text || "Could not generate email draft.";
  } catch (error) {
    console.error("Gemini Email Draft Failed", error);
    return "Error generating draft.";
  }
};