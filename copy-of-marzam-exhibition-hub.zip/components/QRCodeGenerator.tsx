import React from 'react';
import { Download, Share2 } from 'lucide-react';

export const QRCodeGenerator: React.FC = () => {
  // In a real app, this URL would be the deployed URL.
  // For this demo, we assume the user is viewing this component and wants to print it.
  const appUrl = window.location.href.split('#')[0]; 
  
  // Using a reliable public API for QR generation to keep the app lightweight
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(appUrl)}&color=292524`;

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-xl border border-stone-200 text-center">
      <div className="mb-6">
        <h2 className="text-2xl font-serif font-bold text-stone-900">Exhibition Access Code</h2>
        <p className="text-stone-500 mt-2">Print this code and place it at the entrance.</p>
      </div>
      
      <div className="bg-stone-50 p-6 rounded-xl border border-stone-100 inline-block mb-6 relative group">
        <img 
          src={qrCodeUrl} 
          alt="Visitor Access QR Code" 
          className="w-64 h-64 mix-blend-multiply" 
        />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/5 rounded-xl pointer-events-none">
            {/* Overlay effect */}
        </div>
      </div>

      <div className="flex flex-col space-y-3">
        <button 
            onClick={() => window.print()}
            className="w-full flex items-center justify-center space-x-2 bg-stone-900 hover:bg-stone-800 text-white py-3 rounded-lg font-bold transition-all"
        >
          <Download size={18} />
          <span>Print / Save as PDF</span>
        </button>
        <p className="text-xs text-stone-400 mt-4">
          Scan to open the Visitor Registration Form
        </p>
      </div>
    </div>
  );
};
