export interface VisitorRequest {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  organization?: string;
  interest: VisitorInterest;
  message: string;
  timestamp: number;
  status: 'pending' | 'reviewed' | 'contacted';
}

export enum VisitorInterest {
  FURNITURE_DECOR = 'Furniture & Decor',
  DESIGN_CONSULTATION = 'Interior Design Consultation',
  COMMERCIAL_PROJECT = 'Commercial Project',
  RESIDENTIAL_PROJECT = 'Residential Project',
  CUSTOM_FABRICATION = 'Custom Fabrication',
  COLLABORATION = 'B2B Collaboration',
  GENERAL_INQUIRY = 'General Inquiry'
}

export interface AnalysisResult {
  summary: string;
  topInterests: string[];
  suggestedAction: string;
}