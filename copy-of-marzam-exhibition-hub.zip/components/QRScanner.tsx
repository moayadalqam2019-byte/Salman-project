import React, { useEffect, useState, useRef } from 'react';
import { X, Camera, AlertCircle, CheckCircle2 } from 'lucide-react';

interface QRScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
}

export const QRScanner: React.FC<QRScannerProps> = ({ onScan, onClose }) => {
  const [scanError, setScanError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const scannerRef = useRef<any>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    isMountedRef.current = true;
    const Html5Qrcode = (window as any).Html5Qrcode;
    
    if (!Html5Qrcode) {
      setScanError("Scanner library not loaded. Please refresh the page.");
      return;
    }

    const startScanner = async () => {
       try {
          // Use the Html5Qrcode class directly for better control than Html5QrcodeScanner
          const html5QrCode = new Html5Qrcode("reader");
          scannerRef.current = html5QrCode;
          
          await html5QrCode.start(
            { facingMode: "environment" }, // Prefer back camera
            { 
              fps: 10, 
              qrbox: { width: 250, height: 250 },
              aspectRatio: 1
            },
            (decodedText: string) => {
              if (isMountedRef.current) {
                 setIsSuccess(true);
                 
                 // Haptic feedback if supported
                 if (navigator.vibrate) navigator.vibrate(200);
                 
                 // Pause the scanner to freeze the frame on the success moment
                 html5QrCode.pause(true);

                 // Delay calling onScan to let the user see the success animation
                 setTimeout(() => {
                    if (isMountedRef.current) {
                        onScan(decodedText);
                    }
                 }, 1200); 
              }
            },
            (errorMessage: string) => {
               // Ignore frame parse errors (they happen every frame a QR isn't found)
            }
          );
       } catch (err: any) {
          if (!isMountedRef.current) return;
          console.error("Scanner Start Error:", err);
          
          // Default friendly message
          let msg = "Could not access camera. Please ensure camera permissions are granted and try again.";
          
          // Specific handling for common hardware issues
          if (err?.name === "NotFoundError") {
             msg = "No camera found on this device.";
          } else if (err?.name === "NotReadableError") {
             msg = "Camera is currently in use by another application.";
          }
          
          setScanError(msg);
       }
    };

    // Small timeout to ensure DOM is ready
    const timer = setTimeout(() => {
        startScanner();
    }, 100);

    return () => {
      isMountedRef.current = false;
      clearTimeout(timer);
      if (scannerRef.current) {
         try {
            // Attempt to stop and clear. 
            // Note: Html5Qrcode can be picky about stopping if it hasn't fully started, 
            // but the try/catch protects the app from crashing.
            scannerRef.current.stop().then(() => {
                scannerRef.current.clear();
            }).catch((err: any) => {
                console.warn("Scanner stop warning:", err);
            });
         } catch(e) {
            console.warn("Scanner cleanup warning:", e);
         }
      }
    };
  }, [onScan]);

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/95 flex flex-col items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="w-full max-w-md bg-white rounded-2xl overflow-hidden shadow-2xl relative flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-stone-100 p-4 flex justify-between items-center border-b border-stone-200 shrink-0">
           <div className="flex items-center gap-2 text-stone-800 font-bold">
              <Camera size={20} className="text-amber-600"/>
              <span>Scan Item QR Code</span>
           </div>
           <button 
             onClick={onClose} 
             className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-stone-200 text-stone-500 hover:text-stone-800 transition-colors"
           >
              <X size={20} />
           </button>
        </div>

        {/* Scanner Area */}
        <div className="p-6 bg-stone-50 relative flex-grow flex flex-col items-center justify-center">
            {/* The Reader Container */}
            <div className={`relative w-full overflow-hidden rounded-xl bg-black transition-all duration-500 ${isSuccess ? 'ring-4 ring-green-500 shadow-[0_0_30px_rgba(34,197,94,0.4)] scale-[1.02]' : 'ring-1 ring-stone-300'}`}>
                
                {/* The div where html5-qrcode renders the video */}
                {!scanError && <div id="reader" className="w-full h-full min-h-[300px]"></div>}
                
                {/* Success Overlay */}
                {isSuccess && (
                  <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/40 backdrop-blur-[2px] animate-in fade-in duration-300">
                    <div className="bg-white rounded-full p-4 shadow-xl transform animate-in zoom-in duration-300 mb-2">
                      <CheckCircle2 size={48} className="text-green-600" />
                    </div>
                    <p className="text-white font-bold text-lg drop-shadow-md">Scanned!</p>
                  </div>
                )}
            </div>
            
            {/* Helper Text */}
            {!scanError && !isSuccess && (
              <p className="text-center text-sm text-stone-500 mt-6 animate-pulse">
                 Align the QR code within the frame to scan.
              </p>
            )}

            {/* Error State Display */}
            {scanError && (
                 <div className="absolute inset-0 bg-stone-50 z-30 flex flex-col items-center justify-center p-6 text-center">
                    <div className="bg-red-100 p-4 rounded-full mb-4">
                        <AlertCircle size={40} className="text-red-600" />
                    </div>
                    <h3 className="text-lg font-bold text-stone-800 mb-2">Scanner Error</h3>
                    <p className="text-stone-600 text-sm mb-6 max-w-xs">{scanError}</p>
                    <button 
                      onClick={onClose}
                      className="px-6 py-3 bg-stone-900 text-white rounded-lg font-bold hover:bg-stone-800 transition-colors shadow-lg"
                    >
                      Close Scanner
                    </button>
                 </div>
            )}
        </div>
      </div>
    </div>
  );
};