import React, { useState } from 'react';
import { VisitorForm } from './components/VisitorForm';
import { OwnerDashboard } from './components/OwnerDashboard';
import { QRCodeGenerator } from './components/QRCodeGenerator';
import { QRScanner } from './components/QRScanner';
import { LayoutDashboard, QrCode, PenTool, ScanLine } from 'lucide-react';

type View = 'visitor' | 'owner' | 'qrcode';

const App: React.FC = () => {
  const [view, setView] = useState<View>('visitor');
  const [showScanner, setShowScanner] = useState(false);
  const [scannedData, setScannedData] = useState<string>('');

  const handleScan = (data: string) => {
    setScannedData(data);
    setShowScanner(false);
    setView('visitor');
  };

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col">
      {/* Navigation Header */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setView('visitor')}>
            <div className="w-8 h-8 bg-amber-500 rounded-tr-lg rounded-bl-lg"></div>
            <h1 className="text-xl font-serif font-bold text-stone-900 tracking-tight">
              MARZAM <span className="font-sans font-light text-stone-500">Interiors</span>
            </h1>
          </div>
          
          <nav className="flex space-x-1 bg-stone-100 p-1 rounded-lg overflow-x-auto">
            <button
              onClick={() => setView('visitor')}
              className={`flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                view === 'visitor' 
                  ? 'bg-white text-stone-900 shadow-sm' 
                  : 'text-stone-500 hover:text-stone-700'
              }`}
            >
              <PenTool size={16} />
              <span className="hidden sm:inline">Visitor Form</span>
            </button>
            <button
              onClick={() => setShowScanner(true)}
              className={`flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap text-stone-500 hover:text-stone-700 hover:bg-white`}
            >
              <ScanLine size={16} />
              <span className="hidden sm:inline">Scan Item</span>
            </button>
            <button
              onClick={() => setView('qrcode')}
              className={`flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                view === 'qrcode' 
                  ? 'bg-white text-stone-900 shadow-sm' 
                  : 'text-stone-500 hover:text-stone-700'
              }`}
            >
              <QrCode size={16} />
              <span className="hidden sm:inline">Get QR Code</span>
            </button>
            <button
              onClick={() => setView('owner')}
              className={`flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${
                view === 'owner' 
                  ? 'bg-white text-indigo-600 shadow-sm' 
                  : 'text-stone-500 hover:text-stone-700'
              }`}
            >
              <LayoutDashboard size={16} />
              <span className="hidden sm:inline">Owner Dashboard</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          {view === 'visitor' && (
            <div className="animate-fade-in-up">
               <div className="text-center mb-10">
                  <h2 className="text-4xl font-serif font-bold text-stone-900 mb-4">Welcome to Marzam</h2>
                  <p className="text-stone-500 text-lg max-w-2xl mx-auto">
                    December 9-14 • Redefining Interior Design & Modern Living
                  </p>
               </div>
               <VisitorForm 
                 initialMessage={scannedData} 
                 onReset={() => setScannedData('')}
               />
            </div>
          )}

          {view === 'qrcode' && (
            <div className="animate-fade-in-up py-10">
               <QRCodeGenerator />
            </div>
          )}

          {view === 'owner' && (
            <div className="animate-fade-in">
              <div className="mb-8 border-b border-stone-200 pb-4">
                 <h2 className="text-2xl font-serif font-bold text-stone-900">Owner Dashboard</h2>
                 <p className="text-stone-500">Manage client requests and analyze design trends</p>
              </div>
              <OwnerDashboard />
            </div>
          )}
        </div>
      </main>

      {/* QR Scanner Overlay */}
      {showScanner && (
        <QRScanner 
          onScan={handleScan} 
          onClose={() => setShowScanner(false)} 
        />
      )}

      {/* Footer */}
      <footer className="bg-stone-900 text-stone-400 py-8 border-t border-stone-800">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center text-sm">
          <p>© 2024 Marzam Interior Design Exhibition. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <span className="hover:text-white cursor-pointer transition">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer transition">Terms of Service</span>
            <span className="hover:text-white cursor-pointer transition">Contact Support</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;