import { VisitorRequest } from '../types';

const STORAGE_KEY = 'marzam_visitor_requests';

export const saveRequest = (request: Omit<VisitorRequest, 'id' | 'timestamp' | 'status'>): VisitorRequest => {
  const existingData = getRequests();
  const newRequest: VisitorRequest = {
    ...request,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
    status: 'pending',
  };
  
  const updatedData = [newRequest, ...existingData];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedData));
  return newRequest;
};

export const getRequests = (): VisitorRequest[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

export const updateRequestStatus = (id: string, status: VisitorRequest['status']): void => {
  const requests = getRequests();
  const updated = requests.map(req => req.id === id ? { ...req, status } : req);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};

export const clearRequests = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};
