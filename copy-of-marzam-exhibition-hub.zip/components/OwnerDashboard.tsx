import React, { useEffect, useState } from 'react';
import { VisitorRequest, AnalysisResult, VisitorInterest } from '../types';
import { getRequests, updateRequestStatus, clearRequests } from '../services/storage';
import { analyzeVisitorData, generateEmailDraft } from '../services/gemini';
import { RefreshCw, Sparkles, Mail, Trash2, Filter, Loader2, BarChart3, Download, Building2, Phone, Check } from 'lucide-react';

export const OwnerDashboard: React.FC = () => {
  const [requests, setRequests] = useState<VisitorRequest[]>([]);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [loadingDraftId, setLoadingDraftId] = useState<string | null>(null);
  const [emailDraft, setEmailDraft] = useState<{id: string, text: string} | null>(null);
  
  // Tooltip state
  const [tooltip, setTooltip] = useState<{text: string, x: number, y: number} | null>(null);
  
  // Copy success state
  const [copySuccess, setCopySuccess] = useState(false);
  
  // Filtering state
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterInterest, setFilterInterest] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const data = getRequests();
    // Sort by newest first
    setRequests(data.sort((a, b) => b.timestamp - a.timestamp));
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    const result = await analyzeVisitorData(requests);
    setAnalysis(result);
    setIsAnalyzing(false);
  };

  const handleDraftEmail = async (visitor: VisitorRequest) => {
    setLoadingDraftId(visitor.id);
    setCopySuccess(false);
    const draft = await generateEmailDraft(visitor);
    setEmailDraft({ id: visitor.id, text: draft });
    setLoadingDraftId(null);
  };

  const handleStatusUpdate = (id: string) => {
    updateRequestStatus(id, 'reviewed');
    loadData();
  };

  const handleClear = () => {
    if(confirm("Are you sure you want to delete all data?")) {
      clearRequests();
      loadData();
      setAnalysis(null);
    }
  };

  const downloadCSV = (data: VisitorRequest[], filenamePrefix: string) => {
    const headers = ['ID', 'Date', 'Time', 'Full Name', 'Organization', 'Email', 'Phone', 'Interest', 'Message', 'Status'];
    
    // Robust escaping function for CSV
    const escapeCsv = (str: string | undefined | null) => {
      if (str === undefined || str === null) return '""';
      const stringValue = String(str);
      // Escape quotes by doubling them, and wrap in quotes to handle commas/newlines/quotes in data
      return `"${stringValue.replace(/"/g, '""')}"`;
    };

    const rows = data.map(r => {
      const dateObj = new Date(r.timestamp);
      return [
        r.id,
        dateObj.toLocaleDateString(),
        dateObj.toLocaleTimeString(),
        escapeCsv(r.fullName),
        escapeCsv(r.organization || ''),
        escapeCsv(r.email),
        escapeCsv(r.phone),
        escapeCsv(r.interest),
        escapeCsv(r.message),
        escapeCsv(r.status)
      ];
    });
    
    const csvContent = [
      headers.join(','), 
      ...rows.map(r => r.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `marzam_${filenamePrefix}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleTooltip = (e: React.MouseEvent, text: string) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTooltip({
      text,
      x: rect.left + rect.width / 2,
      y: rect.top - 8 // Position slightly above the element
    });
  };

  // Filter Logic
  const filteredRequests = requests.filter(req => {
    const matchesStatus = filterStatus === 'all' || req.status === filterStatus;
    const matchesInterest = filterInterest === 'all' || req.interest === filterInterest;
    return matchesStatus && matchesInterest;
  });

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      
      {/* Header Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-stone-200">
          <h3 className="text-stone-500 text-sm font-bold uppercase tracking-wider">Total Requests</h3>
          <p className="text-4xl font-serif font-bold text-stone-800 mt-2">{requests.length}</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-stone-200">
          <h3 className="text-stone-500 text-sm font-bold uppercase tracking-wider">Pending Review</h3>
          <p className="text-4xl font-serif font-bold text-amber-600 mt-2">
            {requests.filter(r => r.status === 'pending').length}
          </p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-stone-200 flex flex-col justify-center items-start">
           <button 
            onClick={handleAnalyze}
            disabled={isAnalyzing || requests.length === 0}
            className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white py-3 px-4 rounded-lg font-medium transition-all shadow-md disabled:opacity-50"
          >
            {isAnalyzing ? <Loader2 className="animate-spin" size={20}/> : <Sparkles size={20} />}
            <span>{isAnalyzing ? "Analyzing Data..." : "Analyze with Gemini AI"}</span>
          </button>
        </div>
      </div>

      {/* AI Analysis Section */}
      {analysis && (
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-8 rounded-2xl border border-indigo-100 shadow-inner animate-fade-in">
          <h3 className="text-xl font-bold text-indigo-900 flex items-center gap-2 mb-4">
            <Sparkles className="text-indigo-600" size={20}/> AI Insights
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-bold text-indigo-800 mb-2 text-sm uppercase">Executive Summary</h4>
              <p className="text-indigo-900/80 leading-relaxed">{analysis.summary}</p>
            </div>
            <div className="space-y-4">
               <div>
                <h4 className="font-bold text-indigo-800 mb-2 text-sm uppercase">Top Interests</h4>
                <div className="flex flex-wrap gap-2">
                  {analysis.topInterests.map((tag, i) => (
                    <span key={i} className="bg-white text-indigo-700 px-3 py-1 rounded-full text-sm font-medium shadow-sm border border-indigo-100">
                      {tag}
                    </span>
                  ))}
                </div>
               </div>
               <div>
                  <h4 className="font-bold text-indigo-800 mb-2 text-sm uppercase">Recommended Action</h4>
                  <p className="text-indigo-900/80 italic border-l-4 border-indigo-400 pl-4">{analysis.suggestedAction}</p>
               </div>
            </div>
          </div>
        </div>
      )}

      {/* Data Table Controls */}
      <div className="flex flex-col md:flex-row justify-between items-end md:items-center gap-4 bg-white p-4 rounded-xl border border-stone-200 shadow-sm">
        <div className="flex items-center gap-2 text-stone-800 font-bold text-lg">
           <BarChart3 size={24} className="text-stone-500"/>
           <span>Visitor Requests</span>
        </div>

        <div className="flex flex-wrap gap-3 items-center w-full md:w-auto">
          {/* Status Filter */}
          <select 
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 rounded-lg border border-stone-300 text-sm focus:ring-2 focus:ring-amber-500 outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="reviewed">Reviewed</option>
            <option value="contacted">Contacted</option>
          </select>

          {/* Interest Filter */}
          <select
            value={filterInterest}
            onChange={(e) => setFilterInterest(e.target.value)}
            className="px-3 py-2 rounded-lg border border-stone-300 text-sm focus:ring-2 focus:ring-amber-500 outline-none max-w-[200px]"
          >
            <option value="all">All Interests</option>
            {Object.values(VisitorInterest).map(i => (
              <option key={i} value={i}>{i}</option>
            ))}
          </select>

          <div className="h-6 w-px bg-stone-300 mx-1 hidden md:block"></div>

          <button onClick={loadData} className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg transition" title="Refresh">
            <RefreshCw size={18} />
          </button>
          
          <button 
            onClick={() => downloadCSV(filteredRequests, 'filtered_visitors')} 
            disabled={filteredRequests.length === 0}
            className="p-2 text-stone-500 hover:bg-stone-100 hover:text-green-600 rounded-lg transition disabled:opacity-30" 
            title="Export Filtered Requests"
          >
            <Download size={18} />
          </button>

          <button 
            onClick={() => downloadCSV(requests, 'all_visitors')}
            disabled={requests.length === 0}
            className="flex items-center gap-1 px-3 py-2 bg-stone-100 hover:bg-green-50 text-stone-600 hover:text-green-700 text-xs font-bold rounded-lg transition disabled:opacity-30 border border-stone-200" 
            title="Export All Requests"
          >
            <Download size={14} />
            <span>Export All</span>
          </button>
          
          <button onClick={handleClear} className="p-2 text-stone-400 hover:bg-red-50 hover:text-red-600 rounded-lg transition" title="Clear All Data">
            <Trash2 size={18} />
          </button>
        </div>
      </div>
      
      {/* Data Table */}
      <div className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
        {filteredRequests.length === 0 ? (
          <div className="p-12 text-center text-stone-400">
            <Filter className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p>{requests.length === 0 ? "No requests found yet." : "No requests match your filters."}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-stone-50 text-stone-500 text-xs uppercase tracking-wider">
                  <th className="p-4 font-semibold">Status</th>
                  <th className="p-4 font-semibold">Visitor Details</th>
                  <th className="p-4 font-semibold">Interest</th>
                  <th className="p-4 font-semibold w-1/3">Message</th>
                  <th className="p-4 font-semibold text-center">Contact</th>
                  <th className="p-4 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-stone-50 transition-colors duration-200">
                    <td className="p-4">
                      <span className={`inline-block w-2.5 h-2.5 rounded-full mr-2 ${req.status === 'pending' ? 'bg-amber-500' : 'bg-green-500'}`}></span>
                      <span className="text-xs font-bold text-stone-500 uppercase">{req.status}</span>
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-stone-800">{req.fullName}</div>
                      {req.organization && (
                        <div className="flex items-center gap-1 text-xs font-semibold text-indigo-600 mt-0.5">
                          <Building2 size={10} /> {req.organization}
                        </div>
                      )}
                      <div className="text-sm text-stone-500 mt-1">{req.email}</div>
                      <div className="text-xs text-stone-400">{req.phone}</div>
                    </td>
                    <td className="p-4">
                      <span className="bg-stone-100 text-stone-700 px-2 py-1 rounded text-xs font-medium border border-stone-200">
                        {req.interest}
                      </span>
                    </td>
                    <td className="p-4">
                      <p 
                        className="text-sm text-stone-600 line-clamp-2 cursor-help"
                        onMouseEnter={(e) => handleTooltip(e, req.message)}
                        onMouseLeave={() => setTooltip(null)}
                      >
                        {req.message}
                      </p>
                    </td>
                    <td className="p-4 text-center">
                       <div className="flex items-center justify-center space-x-3">
                          <a 
                            href={`mailto:${req.email}`} 
                            onMouseEnter={(e) => handleTooltip(e, req.email)}
                            onMouseLeave={() => setTooltip(null)}
                            className="p-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 hover:text-indigo-700 rounded-full transition-all duration-200 shadow-sm hover:shadow-md border border-indigo-100"
                          >
                            <Mail size={20} />
                          </a>
                          <a 
                            href={`tel:${req.phone}`} 
                            onMouseEnter={(e) => handleTooltip(e, req.phone)}
                            onMouseLeave={() => setTooltip(null)}
                            className="p-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 hover:text-emerald-700 rounded-full transition-all duration-200 shadow-sm hover:shadow-md border border-emerald-100"
                          >
                            <Phone size={20} />
                          </a>
                       </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        {req.status === 'pending' && (
                          <button 
                            onClick={() => handleStatusUpdate(req.id)}
                            className="text-xs bg-stone-200 hover:bg-stone-300 text-stone-700 px-3 py-1.5 rounded-md transition"
                          >
                            Mark Reviewed
                          </button>
                        )}
                        <button 
                          onClick={() => handleDraftEmail(req)}
                          disabled={loadingDraftId === req.id}
                          className="text-xs flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border border-indigo-200 px-3 py-1.5 rounded-md transition disabled:opacity-50 min-w-[100px] justify-center"
                        >
                          {loadingDraftId === req.id ? <Loader2 size={12} className="animate-spin"/> : <Mail size={12} />}
                          {loadingDraftId === req.id ? "Drafting..." : "Draft Email"}
                        </button>
                      </div>
                      {emailDraft?.id === req.id && (
                        <div className="absolute z-10 mt-2 w-96 bg-white p-4 rounded-xl shadow-xl border border-indigo-100 animate-in fade-in zoom-in duration-200 right-10">
                          <div className="flex justify-between items-center mb-2">
                            <h5 className="font-bold text-indigo-900 text-sm">AI Draft</h5>
                            <button onClick={() => setEmailDraft(null)} className="text-stone-400 hover:text-stone-600">x</button>
                          </div>
                          <textarea 
                            readOnly 
                            className="w-full text-sm text-stone-600 bg-stone-50 p-3 rounded-lg border border-stone-200 h-40 focus:outline-none"
                            value={emailDraft.text} 
                          />
                          <button 
                            onClick={() => {
                                navigator.clipboard.writeText(emailDraft.text);
                                setCopySuccess(true);
                                setTimeout(() => setCopySuccess(false), 2000);
                            }}
                            className={`w-full mt-2 flex items-center justify-center gap-2 text-white text-xs font-bold py-2 rounded-lg transition-all duration-200 ${
                                copySuccess ? 'bg-green-600 hover:bg-green-700' : 'bg-indigo-600 hover:bg-indigo-700'
                            }`}
                          >
                            {copySuccess ? (
                                <>
                                    <Check size={14} className="animate-in zoom-in duration-300" />
                                    <span>Copied!</span>
                                </>
                            ) : (
                                "Copy to Clipboard"
                            )}
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Floating Tooltip */}
      {tooltip && (
        <div 
          className="fixed z-50 px-4 py-3 bg-stone-900/95 backdrop-blur-sm text-white text-xs font-medium rounded-xl shadow-2xl pointer-events-none transform -translate-x-1/2 -translate-y-full max-w-xs sm:max-w-md whitespace-pre-wrap leading-relaxed border border-stone-700"
          style={{ left: tooltip.x, top: tooltip.y }}
        >
          {tooltip.text}
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-stone-900/95"></div>
        </div>
      )}
    </div>
  );
};
